$(".btn").click(function(){
    alert("login page")
});

$(".container-form .btn").click(function () {
    $(".container").addClass("active");
});    